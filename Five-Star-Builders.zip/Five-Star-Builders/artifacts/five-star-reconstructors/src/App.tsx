import { useState, type FormEvent } from 'react';
import { ArrowDownRight, ArrowRight, Check, ChevronDown, HardHat, Menu, MoveUpRight, ShieldCheck, Wrench, X } from 'lucide-react';

const companyEmail = 'gchristopher@fivestarreconstructors.com';

function BrandMark({ inverse = false }: { inverse?: boolean }) {
  return (
    <a href="#top" className={`brand ${inverse ? 'brand-inverse' : ''}`} aria-label="Five Star Reconstructors home" data-testid="link-home">
      <span className="brand-symbol" aria-hidden="true">
        <svg viewBox="0 0 50 50" fill="none">
          <path d="M25 2.8 30.8 18l16.2.9-12.4 10.5 4.2 15.7L25 36.5 11.2 45.1l4.2-15.7L3 18.9 19.2 18 25 2.8Z" fill="currentColor" />
          <path d="M13.2 31.6h23.6M17.1 36.8h15.8" stroke="var(--brand-mark-line)" strokeWidth="2.2" strokeLinecap="square" />
        </svg>
      </span>
      <span className="brand-copy"><strong>FIVE STAR</strong><small>RECONSTRUCTORS INC.</small></span>
    </a>
  );
}

const serviceItems = [
  { id: '01', title: 'Residential reconstruction', text: 'Thoughtful repairs and rebuilding for the place you call home.', icon: HardHat },
  { id: '02', title: 'Commercial construction', text: 'Practical improvements and reconstruction for working properties.', icon: Wrench },
  { id: '03', title: 'Property repairs', text: 'A considered approach to the details that keep a building working well.', icon: ShieldCheck },
];

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const closeMenu = () => setMenuOpen(false);
  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const subject = `Project inquiry — ${String(form.get('projectType'))}`;
    const body = [
      `Name: ${form.get('name')}`,
      `Email: ${form.get('email')}`,
      `Phone: ${form.get('phone')}`,
      `Project type: ${form.get('projectType')}`,
      `Project location: ${form.get('location')}`,
      '',
      'Project details:',
      form.get('details'),
    ].join('\n');
    setSubmitted(true);
    window.location.href = `mailto:${companyEmail}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  };

  return (
    <div className="site-shell" id="top">
      <div className="utility-bar">
        <div className="wrap utility-inner">
          <span>Serving residential &amp; commercial properties</span>
          <a href="tel:+19374890578" data-testid="link-phone-top">Call us <b>937-489-0578</b></a>
        </div>
      </div>
      <header className="site-header">
        <div className="wrap header-inner">
          <BrandMark />
          <button className="menu-toggle" type="button" aria-label={menuOpen ? 'Close navigation' : 'Open navigation'} aria-expanded={menuOpen} onClick={() => setMenuOpen(!menuOpen)} data-testid="button-menu">
            {menuOpen ? <X size={23} /> : <Menu size={23} />}
          </button>
          <nav className={`main-nav ${menuOpen ? 'nav-open' : ''}`} aria-label="Main navigation">
            <a className="nav-link" href="#services" onClick={closeMenu} data-testid="link-services-nav">Services</a>
            <a className="nav-link" href="#work" onClick={closeMenu} data-testid="link-work-nav">Our work</a>
            <a className="nav-link" href="#approach" onClick={closeMenu} data-testid="link-approach-nav">Our approach</a>
            <a className="nav-cta" href="#contact" onClick={closeMenu} data-testid="link-quote-nav">Request a quote <ArrowRight size={15} /></a>
          </nav>
        </div>
      </header>

      <main>
        <section className="hero">
          <div className="hero-image photo-frame">
            <img src="/images/hero-home.jpg" alt="Florida home exterior with reconstruction work underway" width="1600" height="1000" fetchPriority="high" />
          </div>
          <div className="hero-scrim" />
          <div className="wrap hero-content">
            <p className="eyebrow hero-eyebrow fade-up"><span /> Satsuma, Florida · Residential &amp; commercial</p>
            <h1 className="display fade-up fade-delay-1">Good work.<br /><em>Built to hold up.</em></h1>
            <p className="hero-intro fade-up fade-delay-2">Construction and reconstruction with a steady hand, clear communication, and care for the property in our charge.</p>
            <div className="hero-actions fade-up fade-delay-2">
              <a className="button-primary" href="#contact" data-testid="link-hero-quote">Talk through your project <ArrowRight size={17} /></a>
              <a className="text-link light-link" href="#services" data-testid="link-explore-services">Explore our services <ArrowDownRight size={17} /></a>
            </div>
          </div>
          <div className="hero-caption"><span>01 / 04</span><span>Careful work, from the ground up.</span></div>
        </section>

        <section className="intro-section" aria-labelledby="intro-title">
          <div className="wrap intro-grid">
            <div className="intro-index"><span className="eyebrow">A steady partner</span><span className="index-rule" /></div>
            <div className="intro-copy">
              <h2 className="display" id="intro-title">When a property needs attention, <em>the details matter.</em></h2>
              <div className="intro-bottom">
                <p>Five Star Reconstructors Inc. serves homeowners and commercial property owners from Satsuma, Florida. We bring a hands-on mindset to construction, reconstruction, and repair—taking time to understand the work and follow it through with care.</p>
                <a className="text-link" href="#approach" data-testid="link-how-we-work">How we work <ArrowRight size={16} /></a>
              </div>
            </div>
            <div className="intro-stamp" aria-hidden="true"><span>FIVE STAR</span><strong>5</strong><span>BUILT WITH CARE</span></div>
          </div>
        </section>

        <section className="services-section" id="services" aria-labelledby="services-title">
          <div className="wrap">
            <div className="section-heading">
              <div><p className="eyebrow accent-eyebrow">What we do</p><h2 className="display" id="services-title">Work that makes<br /><em>your property whole.</em></h2></div>
              <p className="section-aside">From a focused repair to a broader reconstruction, we start by listening and build a clear path forward.</p>
            </div>
            <div className="service-list">
              {serviceItems.map(({ id, title, text, icon: Icon }) => (
                <article className="service-row" key={id} data-testid={`card-service-${id}`}>
                  <span className="service-number">{id}</span>
                  <span className="service-icon"><Icon size={22} strokeWidth={1.5} /></span>
                  <div className="service-copy"><h3>{title}</h3><p>{text}</p></div>
                  <a href="#contact" className="service-arrow" aria-label={`Ask about ${title}`} data-testid={`link-service-${id}`}><ArrowRight size={20} /></a>
                </article>
              ))}
            </div>
            <p className="service-note">Have something specific in mind? <a href="#contact">Tell us what you’re looking to take care of.</a></p>
          </div>
        </section>

        <section className="work-section" id="work" aria-labelledby="work-title">
          <div className="wrap">
            <div className="work-heading">
              <div><p className="eyebrow accent-eyebrow">A look at the work</p><h2 className="display" id="work-title">Made for the <em>long run.</em></h2></div>
              <p>Every property has its own needs. These illustrative project scenes reflect the kind of thoughtful construction and reconstruction we’re here to discuss.</p>
            </div>
            <div className="project-grid">
              <figure className="project project-large">
                <div className="project-image photo-frame"><img src="/images/finished-home.jpg" alt="A Florida-style home exterior shown after renovation" width="1400" height="900" loading="lazy" /></div>
                <figcaption><span>Residential</span><span>Exterior renewal <ArrowUpRightIcon /></span></figcaption>
              </figure>
              <figure className="project project-tall">
                <div className="project-image photo-frame"><img src="/images/commercial-renovation.jpg" alt="Commercial interior with timber construction work in progress" width="1100" height="900" loading="lazy" /></div>
                <figcaption><span>Commercial</span><span>Interior improvement <ArrowUpRightIcon /></span></figcaption>
              </figure>
              <figure className="project project-wide">
                <div className="project-image photo-frame"><img src="/images/residential-detail.jpg" alt="Careful residential siding and trim work underway" width="1200" height="800" loading="lazy" /></div>
                <figcaption><span>Residential</span><span>Detail &amp; repair <ArrowUpRightIcon /></span></figcaption>
              </figure>
            </div>
            <p className="portfolio-note">Illustrative construction imagery. Shown as examples of the types of work we can discuss—not representations of specific completed projects.</p>
          </div>
        </section>

        <section className="approach-section" id="approach" aria-labelledby="approach-title">
          <div className="approach-photo photo-frame"><img src="/images/hero-home.jpg" alt="Roofline and framing details at a residential construction site" width="1200" height="1100" loading="lazy" /></div>
          <div className="approach-content">
            <p className="eyebrow">The Five Star approach</p>
            <h2 className="display" id="approach-title">Respect the property.<br /><em>Do the work right.</em></h2>
            <p className="approach-lead">A good project is more than the finished surface. It’s the way the work is understood, planned, and cared for along the way.</p>
            <ol className="process-list">
              <li><span>01</span><div><h3>Start with a conversation</h3><p>Tell us what’s going on, what matters most, and where the property is located.</p></div></li>
              <li><span>02</span><div><h3>Understand the scope</h3><p>We’ll learn more about the work you have in mind and discuss sensible next steps.</p></div></li>
              <li><span>03</span><div><h3>Move forward clearly</h3><p>With the project understood, we can talk through the work and how to proceed.</p></div></li>
            </ol>
            <a className="button-outline" href="#contact" data-testid="link-approach-quote">Tell us about your project <ArrowRight size={17} /></a>
          </div>
        </section>

        <section className="values-band" aria-label="Our commitment">
          <div className="wrap values-inner">
            <span className="values-mark"><Check size={20} /></span>
            <p>Clear conversations. Considerate work. A property treated with care.</p>
            <span className="values-location">Satsuma, Florida <span>·</span> Serving nearby communities</span>
          </div>
        </section>

        <section className="contact-section" id="contact" aria-labelledby="contact-title">
          <div className="wrap contact-layout">
            <div className="contact-intro">
              <p className="eyebrow accent-eyebrow">Start a conversation</p>
              <h2 className="display" id="contact-title">Tell us what<br /><em>needs doing.</em></h2>
              <p className="contact-description">Share a few details and we’ll have a better place to begin. No project is too early for a conversation.</p>
              <div className="contact-details">
                <a href={`mailto:${companyEmail}`} data-testid="link-email-contact"><span className="contact-label">Email</span><span>{companyEmail}</span><MoveUpRight size={15} /></a>
                <a href="tel:+19374890578" data-testid="link-phone-contact"><span className="contact-label">Phone</span><span>937-489-0578</span><MoveUpRight size={15} /></a>
                <div><span className="contact-label">Based in</span><span>108 Ross Rd<br />Satsuma, FL 32189</span></div>
              </div>
            </div>
            <form className="quote-form" onSubmit={handleSubmit}>
              <div className="form-heading"><h3>Request a project conversation</h3><span>* Required</span></div>
              <div className="form-grid">
                <label className="field"><span>Your name <b>*</b></span><input name="name" type="text" autoComplete="name" placeholder="Name" required data-testid="input-name" /></label>
                <label className="field"><span>Email address <b>*</b></span><input name="email" type="email" autoComplete="email" placeholder="you@example.com" required data-testid="input-email" /></label>
                <label className="field"><span>Phone number <b>*</b></span><input name="phone" type="tel" autoComplete="tel" placeholder="(000) 000-0000" required data-testid="input-phone" /></label>
                <label className="field select-field"><span>Project type <b>*</b></span><select name="projectType" defaultValue="" required data-testid="select-project-type"><option value="" disabled>Select a type</option><option>Residential reconstruction</option><option>Commercial construction</option><option>Property repair</option><option>Other / not sure yet</option></select><ChevronDown size={16} /></label>
                <label className="field field-full"><span>Project location <b>*</b></span><input name="location" type="text" autoComplete="street-address" placeholder="City, state or property address" required data-testid="input-location" /></label>
                <label className="field field-full"><span>Tell us about the work <b>*</b></span><textarea name="details" rows={4} placeholder="What needs attention? Include any details that would help us understand." required data-testid="input-details" /></label>
              </div>
              <div className="form-submit-row">
                <button className="button-primary submit-button" type="submit" data-testid="button-submit-quote">{submitted ? 'Open email again' : 'Prepare my email'} <ArrowRight size={17} /></button>
                <p>Your email app will open with these details addressed to Five Star Reconstructors.</p>
              </div>
              {submitted && <p className="submit-status" role="status" data-testid="status-email-prepared">Your email app should open with your project information. If it doesn’t, email us directly at <a href={`mailto:${companyEmail}`}>{companyEmail}</a>.</p>}
            </form>
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <div className="wrap footer-main">
          <div className="footer-brand"><BrandMark inverse /><p>Construction &amp; reconstruction<br />in Satsuma, Florida and nearby communities.</p></div>
          <div className="footer-links"><span className="eyebrow">Explore</span><a href="#services" data-testid="link-footer-services">Services</a><a href="#work" data-testid="link-footer-work">Project imagery</a><a href="#approach" data-testid="link-footer-approach">Our approach</a><a href="#contact" data-testid="link-footer-contact">Request a quote</a></div>
          <div className="footer-contact"><span className="eyebrow">Get in touch</span><a href={`mailto:${companyEmail}`} data-testid="link-footer-email">{companyEmail}</a><a href="tel:+19374890578" data-testid="link-footer-phone">937-489-0578</a><span>108 Ross Rd<br />Satsuma, FL 32189</span></div>
        </div>
        <div className="wrap footer-bottom"><span>© {new Date().getFullYear()} Five Star Reconstructors Inc.</span><a href="#top" data-testid="link-back-top">Back to top ↑</a></div>
      </footer>
    </div>
  );
}

function ArrowUpRightIcon() {
  return <MoveUpRight size={14} aria-hidden="true" />;
}

export default App;
